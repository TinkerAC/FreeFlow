CREATE TRIGGER playlist_detail_modified_at
                        AFTER UPDATE ON playlist_detail
                        FOR EACH ROW
                        BEGIN
                            UPDATE playlist_detail SET modified_at = CURRENT_TIMESTAMP WHERE playlist_id = OLD.playlist_id AND track_id = OLD.track_id;
                        END;

