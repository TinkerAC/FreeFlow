CREATE TRIGGER hifini_info_modified_at
                        AFTER UPDATE ON hifini_info
                        FOR EACH ROW
                        BEGIN
                            UPDATE hifini_info SET modified_at = CURRENT_TIMESTAMP WHERE data_href = OLD.data_href;
                        END;

