CREATE TRIGGER "playlists_modified_at"
AFTER UPDATE
ON "playlists"
FOR EACH ROW
BEGIN
                            UPDATE playlists SET modified_at = CURRENT_TIMESTAMP WHERE playlist_id = OLD.playlist_id;
                        END;

