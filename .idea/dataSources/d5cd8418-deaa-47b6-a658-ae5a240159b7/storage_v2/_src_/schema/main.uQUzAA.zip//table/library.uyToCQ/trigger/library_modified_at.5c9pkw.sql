CREATE TRIGGER library_modified_at
                        AFTER UPDATE ON library
                        FOR EACH ROW
                        BEGIN
                            UPDATE library SET modified_at = CURRENT_TIMESTAMP WHERE track_id = OLD.track_id;
                        END;

